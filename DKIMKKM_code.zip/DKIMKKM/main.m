close all;
clear;
clc;
warning off;

% 获取当前脚本所在目录，并递归添加到路径
scriptPath = fileparts(mfilename('fullpath'));
addpath(genpath(scriptPath));

% 显式添加关键子目录（确保所有函数可访问）
addpath(genpath(fullfile(scriptPath, 'ClusteringMeasure')));
addpath(genpath(fullfile(scriptPath, 'function')));
addpath(genpath(fullfile(scriptPath, 'FormulationKernels')));
addpath(genpath(fullfile(scriptPath, 'increment')));

% 只检查 DKI-MKKM 所必需的函数
requiredFiles = {'my_DKI_MKKM_clustering', 'calM', 'myFourIndex', ...
                 'kcenter', 'knorm'};
for i = 1:length(requiredFiles)
    if exist(requiredFiles{i}, 'file') ~= 2
        error('必要函数 %s 未找到，请检查文件是否存在于路径中。', requiredFiles{i});
    end
end

% 全局设置：运行次数（可增加以计算标准差）
numRuns = 1;          % 建议设为 1 以节省时间，若需统计可增大
rng('default');

% 加载核矩阵数据集
dataName = 'Air';     % 可替换为其他数据集（如 glass, flower17, AR10P 等）
load(fullfile(scriptPath, 'datasets', [dataName, '_Kmatrix.mat']), 'KH', 'Y');

% 获取聚类相关信息
numclass = length(unique(Y));
numker = size(KH, 3);
num = size(KH, 1);
Y_original = Y;

% 对核矩阵进行中心化和标准化
KH = kcenter(KH);
KH = knorm(KH);
qnorm = 2;            % 归一化范数阶数

% 预分配结果变量（4个指标）
res_mean = zeros(4, 1);   % ACC, NMI, Purity, ARI
res_std  = zeros(4, 1);
time_mean = NaN;
time_std  = 0;

% 用于保存网格搜索的最终数据（用于绘图）
final_mylambdaset = [];
final_alphaset = [];
final_myaccval = [];
final_mynmival = [];
final_mypurval = [];
final_myRIval = [];

% 创建结果保存目录
save_dir = fullfile(scriptPath, 'Results', dataName);
if ~exist(save_dir, 'dir'); mkdir(save_dir); end


%% ==================== DKI-MKKM 运行 ====================
fprintf('\n=== Running DKI-MKKM on %s ===\n', dataName);

% 超参数网格
mylambdaset = 2.^[-15:1:15];   % λ 搜索范围
Htrntrn = calM(KH);            % 计算初始相似性矩阵
alphaset = [0, 0.1, 0.2, 0.4, 0.6, 0.8, 1.0, 2.0, 2.5, 3, 5, 10];   % α 搜索范围
IterMax = 5;                   % 最大迭代次数
k = 40;                        % 近邻数（论文中常用）
wds = 2;
w = floor(2 * numclass);       % 子空间维度

% 存储各次运行的最佳指标
acc_all = zeros(numRuns, 1);
nmi_all = zeros(numRuns, 1);
pur_all = zeros(numRuns, 1);
ari_all = zeros(numRuns, 1);
time_val = NaN;

for run = 1:numRuns
    rng(run);  % 保证可重复性
    % 存储当前运行在所有网格点上的结果
    myaccval = zeros(length(mylambdaset), length(alphaset));
    mynmival = zeros(length(mylambdaset), length(alphaset));
    mypurval = zeros(length(mylambdaset), length(alphaset));
    myRIval  = zeros(length(mylambdaset), length(alphaset));
    iterViewpointIndexs = cell(length(mylambdaset), length(alphaset));

    for il = 1:length(mylambdaset)
        if run == 1
            tic;   % 计时仅第一次运行
        end
        for i2 = 1:length(alphaset)
            [H_normalized8, ~, ~, ~, iterViewpointIndexs{il,i2}, ~] = ...
                my_DKI_MKKM_clustering(KH, k, wds, w, Htrntrn, numclass, qnorm, ...
                                       mylambdaset(il), alphaset(i2), IterMax);
            [myres_mean, ~] = myFourIndex(H_normalized8, Y_original, numclass);
            myaccval(il, i2) = myres_mean(1);
            mynmival(il, i2) = myres_mean(2);
            mypurval(il, i2) = myres_mean(3);
            myRIval(il, i2)  = myres_mean(4);
        end
        if run == 1
            time_val = toc;   % 记录一次完整网格搜索的时间
        end
    end

    % 当前运行的最佳值（取所有网格点的最大值）
    acc_all(run) = max(myaccval(:));
    nmi_all(run) = max(mynmival(:));
    pur_all(run) = max(mypurval(:));
    ari_all(run) = max(myRIval(:));

    % 保留最后一次运行的网格数据用于绘图
    if run == numRuns
        final_mylambdaset = mylambdaset;
        final_alphaset    = alphaset;
        final_myaccval    = myaccval;
        final_mynmival    = mynmival;
        final_mypurval    = mypurval;
        final_myRIval     = myRIval;
    end
end

% 汇总结果
res_mean(:,1) = [mean(acc_all); mean(nmi_all); mean(pur_all); mean(ari_all)];
res_std(:,1)  = [std(acc_all);  std(nmi_all);  std(pur_all);  std(ari_all)];
time_mean     = time_val;
time_std      = 0;


%% ==================== 参数分析绘图 ====================
if ~isempty(final_mylambdaset) && ~isempty(final_alphaset)
    param_plot_dir = fullfile(save_dir, 'DKI_MKKM_param_analysis');
    if ~exist(param_plot_dir, 'dir'); mkdir(param_plot_dir); end

    lambdas = final_mylambdaset;
    alphas  = final_alphaset;

    % 边际平均性能
    mean_acc_over_alpha = mean(final_myaccval, 2);
    mean_nmi_over_alpha = mean(final_mynmival, 2);
    mean_pur_over_alpha = mean(final_mypurval, 2);
    mean_ari_over_alpha = mean(final_myRIval, 2);

    mean_acc_over_lambda = mean(final_myaccval, 1);
    mean_nmi_over_lambda = mean(final_mynmival, 1);
    mean_pur_over_lambda = mean(final_mypurval, 1);
    mean_ari_over_lambda = mean(final_myRIval, 1);

    % 图1：性能随 λ 变化（α 平均）
    figure('Position', [100, 100, 800, 600]);
    plot(log2(lambdas), mean_acc_over_alpha, 'r-o', 'LineWidth', 2, 'MarkerSize', 6); hold on;
    plot(log2(lambdas), mean_nmi_over_alpha, 'g-s', 'LineWidth', 2, 'MarkerSize', 6);
    plot(log2(lambdas), mean_pur_over_alpha, 'b-d', 'LineWidth', 2, 'MarkerSize', 6);
    plot(log2(lambdas), mean_ari_over_alpha, 'm-^', 'LineWidth', 2, 'MarkerSize', 6);
    grid on;
    xlabel('log_2(\lambda)', 'FontSize', 12);
    ylabel('Performance (averaged over \alpha)', 'FontSize', 12);
    title(['DKI-MKKM: Performance vs \lambda (', dataName, ')'], 'FontSize', 14);
    legend('ACC', 'NMI', 'Purity', 'ARI', 'Location', 'best');
    set(gca, 'FontSize', 11);
    saveas(gcf, fullfile(param_plot_dir, 'performance_vs_lambda.png'));

    % 图2：性能随 α 变化（λ 平均）
    figure('Position', [100, 100, 800, 600]);
    plot(alphas, mean_acc_over_lambda, 'r-o', 'LineWidth', 2, 'MarkerSize', 6); hold on;
    plot(alphas, mean_nmi_over_lambda, 'g-s', 'LineWidth', 2, 'MarkerSize', 6);
    plot(alphas, mean_pur_over_lambda, 'b-d', 'LineWidth', 2, 'MarkerSize', 6);
    plot(alphas, mean_ari_over_lambda, 'm-^', 'LineWidth', 2, 'MarkerSize', 6);
    grid on;
    xlabel('\alpha', 'FontSize', 12);
    ylabel('Performance (averaged over \lambda)', 'FontSize', 12);
    title(['DKI-MKKM: Performance vs \alpha (', dataName, ')'], 'FontSize', 14);
    legend('ACC', 'NMI', 'Purity', 'ARI', 'Location', 'best');
    set(gca, 'FontSize', 11);
    saveas(gcf, fullfile(param_plot_dir, 'performance_vs_alpha.png'));

    % 图3：NMI 随 λ 和 α 的热力图
    figure('Position', [100, 100, 800, 600]);
    imagesc(log2(lambdas), alphas, final_mynmival');  % 转置使 x=λ, y=α
    colorbar;
    xlabel('log_2(\lambda)', 'FontSize', 12);
    ylabel('\alpha', 'FontSize', 12);
    title(['DKI-MKKM: NMI (', dataName, ')'], 'FontSize', 14);
    set(gca, 'YDir', 'normal');
    colormap(jet);
    saveas(gcf, fullfile(param_plot_dir, 'nmi_heatmap.png'));
end


%% ==================== 保存结果 ====================
parametersetting = struct();
parametersetting.dataName = dataName;
parametersetting.numclass = numclass;
parametersetting.numker = numker;
parametersetting.num = num;
parametersetting.numRuns = numRuns;
parametersetting.mylambdaset = final_mylambdaset;
parametersetting.alphaset = final_alphaset;
parametersetting.k = k;
parametersetting.wds = wds;
parametersetting.w = w;
parametersetting.IterMax = IterMax;
parametersetting.qnorm = qnorm;

save(fullfile(save_dir, [dataName, '_DKI_MKKM_result.mat']), ...
     'res_mean', 'res_std', 'time_mean', 'time_std', 'parametersetting', ...
     'final_mylambdaset', 'final_alphaset', 'final_myaccval', 'final_mynmival', ...
     'final_mypurval', 'final_myRIval');


%% ==================== 显示结果 ====================
fprintf('\n========== DKI-MKKM Results on %s ==========\n', dataName);
fprintf('  ACC    : %.4f ± %.4f\n', res_mean(1), res_std(1));
fprintf('  NMI    : %.4f ± %.4f\n', res_mean(2), res_std(2));
fprintf('  Purity : %.4f ± %.4f\n', res_mean(3), res_std(3));
fprintf('  ARI    : %.4f ± %.4f\n', res_mean(4), res_std(4));
fprintf('  Runtime: %.4f seconds (single grid search)\n', time_mean);
fprintf('==============================================\n');